library(testthat)
library(dynUtils)

test_check("dynUtils")
